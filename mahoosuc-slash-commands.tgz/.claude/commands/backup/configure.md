---
description: Configure automated backups and retention
argument-hint: "[--target <db|files|all>] [--retention <days>] [--schedule <cron>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /backup:configure - Configure Backups

Set up automated backups with retention policies.

## Usage

```bash
/backup:configure --target db --retention 30
/backup:configure --target all --schedule "0 2 * * *"
```
