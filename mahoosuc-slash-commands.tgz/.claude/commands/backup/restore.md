---
description: Restore from backups to a target environment
argument-hint: "<backup-id> [--target <env>] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /backup:restore - Restore Backup

Restore a backup to a target environment.

## Usage

```bash
/backup:restore backup-2026-01-27 --target staging
/backup:restore backup-2026-01-27 --dry-run
```
