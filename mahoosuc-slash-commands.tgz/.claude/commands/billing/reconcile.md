---
description: Reconcile billing records and transactions
argument-hint: "[--period <month|quarter|year>] [--format <md|csv>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /billing:reconcile - Billing Reconciliation

Reconcile billing data and generate discrepancy report.

## Usage

```bash
/billing:reconcile --period month
```
