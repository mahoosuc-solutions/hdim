---
description: Set up billing and invoicing workflows
argument-hint: "[--provider <stripe|quickbooks|zoho>] [--currency <usd|eur>] [--tax]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /billing:setup - Billing Setup

Configure billing provider, tax settings, and invoices.

## Usage

```bash
/billing:setup --provider stripe --currency usd --tax
```
