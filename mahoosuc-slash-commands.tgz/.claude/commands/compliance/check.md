---
description: Validate compliance against SOC2/PCI/HIPAA controls
argument-hint: "[--framework <soc2|pci|hipaa|all>] [--format <md|json>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /compliance:check - Compliance Check

Generate a compliance checklist with gaps and recommendations.

## Usage

```bash
/compliance:check --framework soc2
/compliance:check --framework all --format json
```
