---
description: Verify API contracts against OpenAPI/AsyncAPI
argument-hint: "[--spec <path>] [--mode <validate|breaking>] [--fail-on <breaking|warning>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /contract:verify - Contract Verification

Validate API contracts and detect breaking changes.

## Usage

```bash
/contract:verify --spec openapi.yml --mode validate
/contract:verify --spec openapi.yml --mode breaking --fail-on breaking
```
