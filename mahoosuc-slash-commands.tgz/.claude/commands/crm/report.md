---
description: Generate CRM performance reports
argument-hint: "[--period <week|month|quarter>] [--format <md|csv>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /crm:report - CRM Report

Generate reports on lead funnel and conversion rates.

## Usage

```bash
/crm:report --period month --format csv
```
