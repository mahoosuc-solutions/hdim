---
description: Sync CRM data with local systems
argument-hint: "[--provider <zoho|hubspot|salesforce>] [--mode <full|incremental>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /crm:sync - CRM Sync

Synchronize CRM data to keep records consistent.

## Usage

```bash
/crm:sync --provider zoho --mode incremental
```
