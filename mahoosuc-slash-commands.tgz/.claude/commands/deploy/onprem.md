---
description: Deploy on-prem using Docker Compose or systemd
argument-hint: "[--host <hostname>] [--strategy <rolling|blue-green>] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /deploy:onprem - On-Prem Deployment

Deploy services to on-prem hardware with safety checks.

## Usage

```bash
/deploy:onprem --host onprem-01 --strategy rolling
/deploy:onprem --dry-run
```
