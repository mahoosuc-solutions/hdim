---
description: Deploy to VPS with optional blue-green or canary
argument-hint: "[--host <hostname>] [--strategy <rolling|blue-green|canary>] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /deploy:vps - VPS Deployment

Deploy services to a VPS with safety checks.

## Usage

```bash
/deploy:vps --host vps-01 --strategy blue-green
/deploy:vps --dry-run
```
