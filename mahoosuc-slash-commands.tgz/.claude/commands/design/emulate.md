---
description: Emulate a design with dry-run analysis, simulation, and static checks
argument-hint: "<design-id> [--mode <dry-run|simulate|static>] [--format <summary|detailed>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /design:emulate - Emulate Design

Run a non-destructive emulation of a design to surface issues before implementation.

## Usage

```bash
/design:emulate <design-id>
/design:emulate <design-id> --mode simulate
/design:emulate <design-id> --format detailed
```

## Output

- Risk and feasibility summary
- Architecture warnings and bottlenecks
- Suggested fixes and next steps
