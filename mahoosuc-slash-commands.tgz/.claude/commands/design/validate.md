---
description: Validate a design across security, performance, cost, and UX dimensions
argument-hint: "<design-id> [--focus <security|performance|cost|ux|all>] [--format <summary|detailed>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /design:validate - Validate Design

Perform multi-perspective validation to ensure a design is ready to implement.

## Usage

```bash
/design:validate <design-id>
/design:validate <design-id> --focus security
/design:validate <design-id> --format detailed
```

## Output

- Validation scorecard
- Critical risks by domain
- Recommended remediation steps
