---
description: Build project artifacts with project-specific tooling
argument-hint: "[--optimize] [--clean]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /dev:build - Build Project

Builds the project using the detected build system (e.g., npm, pnpm, yarn, make).

## Usage

```bash
/dev:build
/dev:build --optimize
/dev:build --clean
```

## Notes

- Uses project-specific build scripts when available.
- Prefer `--clean` for production releases or after dependency updates.
