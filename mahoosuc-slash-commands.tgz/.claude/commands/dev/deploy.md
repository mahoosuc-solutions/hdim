---
description: Deploy the project using the configured deployment workflow
argument-hint: "[--env <staging|production>] [--version <tag>] [--strategy <blue-green|canary|rolling>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /dev:deploy - Deploy Project

Deploys the project using the configured deployment system.

## Usage

```bash
/dev:deploy
/dev:deploy --env staging
/dev:deploy --version v1.2.3
/dev:deploy --strategy blue-green
```

## Notes

- Uses project-specific deployment scripts if present.
- For infrastructure-level deploys, prefer `/devops:deploy`.
