---
description: Generate documentation from templates and project context
argument-hint: "[--target <onboarding|api|architecture|release>] [--format <md|pdf|html>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /docs:generate - Generate Documentation

Generate documentation bundles using project templates and live context.

## Usage

```bash
/docs:generate --target onboarding
/docs:generate --target api --format md
/docs:generate --target architecture --format html
```
