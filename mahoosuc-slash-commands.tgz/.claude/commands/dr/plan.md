---
description: Create a disaster recovery plan and runbook
argument-hint: "[--rto <hours>] [--rpo <minutes>] [--format <md|pdf>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /dr:plan - Disaster Recovery Plan

Generate a DR plan covering RTO/RPO targets, backups, and restore steps.

## Usage

```bash
/dr:plan --rto 4 --rpo 30
/dr:plan --format pdf
```
