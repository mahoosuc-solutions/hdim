---
description: Create onboarding checklist and materials
argument-hint: "[--role <title>] [--format <md|pdf>] [--tools <list>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /hr:onboard - HR Onboarding

Generate onboarding plan, access checklist, and training steps.

## Usage

```bash
/hr:onboard --role "Backend Engineer" --format md
```
