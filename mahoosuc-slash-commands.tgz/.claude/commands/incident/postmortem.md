---
description: Create an incident postmortem with timeline and action items
argument-hint: "[--incident-id <id>] [--format <md|pdf>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /incident:postmortem - Incident Postmortem

Generate a postmortem report with timeline, impact, and remediation items.

## Usage

```bash
/incident:postmortem --incident-id inc-2026-01-27
```
