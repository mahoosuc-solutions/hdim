---
description: Generate incident response runbooks
argument-hint: "[--service <name>] [--severity <sev1|sev2|sev3>] [--format <md|pdf>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /incident:runbook - Incident Runbook

Generate a runbook for incident response and escalation.

## Usage

```bash
/incident:runbook --service api --severity sev2
```
