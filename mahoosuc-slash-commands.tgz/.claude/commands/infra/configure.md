---
description: Configure servers (Nginx, systemd, firewall, SSL)
argument-hint: "<host> [--roles <web|api|db>] [--ssl] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /infra:configure - Configure Servers

Configure services, security, and runtime on provisioned hosts.

## Usage

```bash
/infra:configure 10.0.0.12 --roles web --ssl
/infra:configure vps-01 --roles api --dry-run
```
