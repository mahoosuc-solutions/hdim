---
description: Provision infrastructure with IaC (Terraform/Ansible)
argument-hint: "<environment> [--provider <aws|gcp|azure|onprem>] [--tool <terraform|ansible>] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /infra:provision - Provision Infrastructure

Provision infrastructure using infrastructure-as-code tools.

## Usage

```bash
/infra:provision staging --provider gcp --tool terraform
/infra:provision onprem --tool ansible --dry-run
```
