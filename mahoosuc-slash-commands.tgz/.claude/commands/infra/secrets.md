---
description: Manage infrastructure secrets (Vault/1Password/SM)
argument-hint: "[--provider <vault|1password|aws-sm|gcp-sm>] [--rotate] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /infra:secrets - Secrets Management

Configure and rotate secrets for deployments and services.

## Usage

```bash
/infra:secrets --provider vault
/infra:secrets --provider 1password --rotate
```
