---
description: Analyze logs for errors, anomalies, and root causes
argument-hint: "[--source <file|service>] [--window <minutes>] [--format <summary|detailed>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /log:analyze - Log Analysis

Analyze logs to identify errors and anomalies.

## Usage

```bash
/log:analyze --source api-service --window 60
/log:analyze --source logs/app.log --format detailed
```
