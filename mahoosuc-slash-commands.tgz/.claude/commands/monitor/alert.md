---
description: Create or update monitoring alerts
argument-hint: "[--metric <name>] [--threshold <value>] [--severity <critical|high|medium>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /monitor:alert - Manage Alerts

Create or update alerting rules for critical metrics.

## Usage

```bash
/monitor:alert --metric latency_p95 --threshold 500 --severity high
```
