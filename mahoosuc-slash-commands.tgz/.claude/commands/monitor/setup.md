---
description: Configure monitoring, dashboards, and alerts
argument-hint: "[--stack <prometheus|grafana|datadog>] [--alerts <critical|all>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /monitor:setup - Monitoring Setup

Configure monitoring stack and alerting rules.

## Usage

```bash
/monitor:setup --stack prometheus --alerts all
```
