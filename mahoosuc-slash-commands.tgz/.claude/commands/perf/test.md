---
description: Run performance/load tests and summarize bottlenecks
argument-hint: "[--tool <k6|wrk|locust>] [--duration <seconds>] [--target <url>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /perf:test - Performance Test

Run load tests and produce a performance report.

## Usage

```bash
/perf:test --tool k6 --duration 60 --target https://example.com
```
