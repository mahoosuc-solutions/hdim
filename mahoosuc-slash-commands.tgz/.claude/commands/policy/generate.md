---
description: Generate company policies (security, privacy, HR, IT)
argument-hint: "[--type <security|privacy|hr|it>] [--format <md|pdf>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /policy:generate - Generate Policies

Create policy documents aligned with business needs.

## Usage

```bash
/policy:generate --type security --format md
```
