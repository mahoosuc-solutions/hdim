---
description: Review PII handling, retention, and data flows
argument-hint: "[--scope <product|repo|service>] [--format <md|json>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /privacy:review - Privacy Review

Identify PII flows, retention risks, and recommend mitigations.

## Usage

```bash
/privacy:review --scope repo
/privacy:review --format json
```
