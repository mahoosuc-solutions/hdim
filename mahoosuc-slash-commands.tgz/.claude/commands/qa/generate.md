---
description: Generate tests based on QA plan and codebase
argument-hint: "[--scope <unit|integration|e2e>] [--framework <vitest|jest|pytest>] [--target <path>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /qa:generate - Generate Tests

Create tests aligned to the QA plan.

## Usage

```bash
/qa:generate --scope unit --framework vitest --target src/
/qa:generate --scope e2e --framework playwright
```
