---
description: Create a QA plan with test strategy and coverage
argument-hint: "[--scope <unit|integration|e2e|all>] [--format <md|json>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /qa:plan - QA Plan

Generate a QA plan with test scope and coverage targets.

## Usage

```bash
/qa:plan --scope all
/qa:plan --format json
```
