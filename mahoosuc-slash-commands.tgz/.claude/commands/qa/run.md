---
description: Run QA suites and summarize results
argument-hint: "[--scope <unit|integration|e2e|all>] [--report <json|html>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /qa:run - Run QA

Execute QA suites and produce reports.

## Usage

```bash
/qa:run --scope all --report json
```
