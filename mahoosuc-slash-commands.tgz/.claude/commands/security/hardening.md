---
description: Apply CIS-style hardening and security baselines
argument-hint: "[--target <host|image>] [--profile <cis|custom>] [--dry-run]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /security:hardening - Security Hardening

Apply host/container hardening based on CIS baselines.

## Usage

```bash
/security:hardening --target vps-01 --profile cis
/security:hardening --dry-run
```
