---
description: Run security scans (SAST/DAST/dependency)
argument-hint: "[--type <sast|dast|deps|all>] [--format <json|markdown>] [--fail-on <critical|high>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /security:scan - Security Scan

Run security scans for code, dependencies, and endpoints.

## Usage

```bash
/security:scan --type all --format json
/security:scan --type deps --fail-on high
```
