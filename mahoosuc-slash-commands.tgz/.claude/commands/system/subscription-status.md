---
description: Check Claude Code subscription status and usage configuration
argument-hint: ""
allowed-tools: Task, Bash, Read
model: claude-sonnet-4-5
---

# /system:subscription-status - Subscription Status

Display current subscription status and usage configuration for the assistant runtime.

## Usage

```bash
/system:subscription-status
```
