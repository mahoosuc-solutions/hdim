---
description: Launch the web-based dashboard for visual command execution and monitoring
argument-hint: "[--port <port>] [--open] [--dev]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /ui:dashboard - Launch Dashboard

Launch the native dashboard for visual command execution and monitoring.

## Usage

```bash
/ui:dashboard
/ui:dashboard --port 3000 --open
/ui:dashboard --dev
```
