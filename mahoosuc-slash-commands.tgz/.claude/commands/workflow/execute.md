---
description: Execute a named workflow with optional arguments
argument-hint: "<workflow-id> [--dry-run] [--params <json>]"
allowed-tools: Task, Bash, Read, Write
model: claude-sonnet-4-5
---

# /workflow:execute - Execute Workflow

Run a workflow defined in `.claude/workflows`.

## Usage

```bash
/workflow:execute project-health
/workflow:execute dev-workflow-enhanced --params '{"feature_name":"user auth"}'
/workflow:execute cost-optimization --dry-run
```

## Notes

- Workflow IDs map to `.claude/workflows/<workflow-id>.yaml`
- Use `--dry-run` to preview steps without executing
