---
description: Create a new contact in Zoho CRM with approval workflow
argument-hint: "<email> [--first-name <name>] [--last-name <name>] [--company <name>]"
allowed-tools: Task, Bash, Read, Write, AskUserQuestion
model: claude-sonnet-4-5
---

# /zoho:create-contact - Create Zoho Contact

Create a contact record in Zoho CRM with approval and audit trail support.

## Usage

```bash
/zoho:create-contact person@company.com --first-name Pat --last-name Lee --company Acme
```

## Notes

- Approval workflow is required for CRM writes.
