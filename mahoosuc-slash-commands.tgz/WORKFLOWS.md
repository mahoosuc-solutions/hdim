# Command Workflows & Integration Guide

**Purpose**: Practical workflows for chaining commands to accomplish complex tasks efficiently.

---

## Table of Contents

1. [Quick Start Workflows](#quick-start-workflows)
2. [Daily Operations](#daily-operations)
3. [Weekly Routines](#weekly-routines)
4. [Project Launch Workflows](#project-launch-workflows)
5. [Business Automation](#business-automation)
6. [Integration Patterns](#integration-patterns)

---

## Quick Start Workflows

### Your First 30 Minutes

**Goal**: Get familiar with high-value commands

\`\`\`bash
# 1. Generate a social media post
/social:generate --platform linkedin --topic "your expertise area" --tone professional

# 2. Create a sales outreach email
/sales:outreach prospect@company.com --template warm

# 3. Run an accessibility audit
/accessibility:audit --level AA

# 4. Generate a prompt for a custom task
/prompt:generate "customer support agent for SaaS product"
\`\`\`

**Expected Outcome**:
- Understanding of command syntax
- Real outputs you can use immediately
- Confidence to explore more commands

---

## High-ROI Workflow Examples

### Content Marketing Workflow (Time Savings: 10 hours/week)

\`\`\`bash
# 1. Generate week's content
/social:generate --platform all --topic "industry insights" --count 20

# 2. Check brand voice
/brand:voice --check generated-content.md

# 3. Schedule posts
/social:schedule --content generated-content.md --strategy optimal

# ROI: $169K/year in time savings and lead generation
\`\`\`

---

### Sales Acceleration Workflow (3x faster sales cycle)

\`\`\`bash
LEAD_EMAIL="prospect@company.com"

# 1. Qualify lead
/sales:qualify-lead $LEAD_EMAIL --source website

# 2. Create in CRM (requires approval)
/zoho:create-lead --email $LEAD_EMAIL --source website

# 3. Send personalized outreach
/sales:outreach $LEAD_EMAIL --template warm

# 4. Prepare for demo
/sales:demo-prep $LEAD_EMAIL

# 5. Follow up
/sales:follow-up deal-123 --type check-in
\`\`\`

---

### Accessibility Compliance Workflow ($45K/year ROI)

\`\`\`bash
# 1. Comprehensive audit
/accessibility:audit --level AA

# 2. Auto-fix issues
/accessibility:fix --auto-apply --severity critical

# 3. Validate fixes
/accessibility:test --ci --fail-on high
\`\`\`

---

### Development Lifecycle Workflow (40% faster)

\`\`\`bash
# 1. Create branch
/dev:create-branch feature/new-feature

# 2. Implement
/dev:implement "Add express checkout"

# 3. Review
/dev:review --auto-fix minor

# 4. Create PR
/dev:create-pr

# 5. Deploy
/devops:deploy --environment production
\`\`\`

---

## Integration Patterns

### CI/CD Integration

\`\`\`yaml
# .github/workflows/quality-gates.yml
name: Quality Gates

on: [push, pull_request]

jobs:
  accessibility:
    runs-on: ubuntu-latest
    steps:
      - name: Audit
        run: /accessibility:audit --format json > audit.json
      - name: Enforce Threshold
        run: |
          score=\$(cat audit.json | jq '.score')
          if [ \$score -lt 80 ]; then exit 1; fi
\`\`\`

---

### Zoho CRM Integration

\`\`\`bash
# Full sales cycle automation
LEAD="prospect@company.com"

/sales:qualify-lead $LEAD
/zoho:create-lead --email $LEAD
/zoho:send-email --recipient $LEAD --template welcome
/assistant:remind --reminder "Follow up: $LEAD" --when "3 days"
\`\`\`

---

## Getting Started Checklist

- [ ] Run your first command
- [ ] Set up one daily workflow
- [ ] Create a content batch
- [ ] Process a lead
- [ ] Configure CI/CD integration
- [ ] Schedule social content
- [ ] Create workflow aliases

---

**Total Potential ROI**: $500K+/year
**Time Savings**: 40-60 hours/week
**Efficiency Gain**: 300-500%
