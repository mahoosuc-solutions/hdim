# Workflow Patterns for General Project Management

This guide documents the 6 core workflow patterns designed to support general project management, along with existing workflows to import and adapt.

---

## Quick Reference

### New Workflows (Created)
1. [Project Health Workflow](#1-project-health-workflow) - Weekly health monitoring
2. [Knowledge Maintenance Workflow](#2-knowledge-maintenance-workflow) - Continuous knowledge updates
3. [Cost Optimization Workflow](#3-cost-optimization-workflow) - Monthly cost analysis
4. [Agent Performance Workflow](#4-agent-performance-workflow) - Quarterly agent optimization
5. [Integration Health Workflow](#5-integration-health-workflow) - Daily integration sync
6. [Enhanced Dev Workflow](#6-enhanced-development-workflow) - Feature development with automated checks

### Existing Workflows (Import/Adapt)
- [DEVB System](#existing-devb-system) - Design → Emulate → Validate → Build
- [Agent OS Workflow](#existing-agent-os-workflow) - Spec-driven development
- [Standard Dev Workflow](#existing-standard-dev-workflow) - Core feature development
- [Productivity Workflow](#existing-productivity-workflow) - Universal capture/search

---

## 1. Project Health Workflow

**File**: `.claude/workflows/project-health.yaml`
**Schedule**: Weekly (Monday 9:00 AM)
**Priority**: High

### Purpose
Comprehensive project health monitoring and proactive maintenance to catch issues before they become critical.

### Steps

```mermaid
graph TD
    A[System Health Check] --> B[Dependency Check]
    A --> C{Health Score < 90?}
    C -->|Yes| D[Backup Critical Data]
    B --> E[Generate Health Dashboard]
    D --> E
```

1. **System Health Check** (`/system:health-check`)
   - Checks code health (tests, linter, types, build)
   - Verifies dependencies (outdated packages, vulnerabilities)
   - Monitors infrastructure (services, disk, memory)
   - Validates database (status, size, connections)
   - Scans security (secrets, certificates, auth)

2. **Dependency Check** (`/dev:dependency-check`)
   - Identifies outdated packages
   - Detects security vulnerabilities
   - Categorizes updates (patch, minor, major)

3. **Conditional Backup** (`/system:backup-all`)
   - Triggers if health score < 90
   - Backs up database, configs, files
   - Creates timestamped backup bundle

4. **Generate Dashboard** (`/dashboard:generate project-health`)
   - Visual health dashboard
   - Aggregates metrics from all sources
   - Tracks trends over time

### Decision Points

| Condition | Action | Description |
|-----------|--------|-------------|
| `health_score < 70` | Alert team | Critical health issues - immediate action required |
| `security_issues > 0` | Auto-patch | Apply security fixes automatically |

### Outputs
- `health-report.md` - Comprehensive health status
- `backup-confirmation.txt` - Backup verification
- `dashboard-url` - Live dashboard link

### Usage

**Manual Trigger**:
```bash
# Run full workflow
/workflow:execute project-health

# Run individual steps
/system:health-check
/dev:dependency-check
/system:backup-all
```

**Automated**:
- Runs every Monday at 9:00 AM
- Sends report to `#project-health` Slack channel
- Emails team summary

---

## 2. Knowledge Maintenance Workflow

**File**: `.claude/workflows/knowledge-maintenance.yaml`
**Schedule**: After major feature OR Weekly (Friday 4:00 PM)
**Priority**: Medium

### Purpose
Continuous knowledge base updates to maintain institutional memory and make information discoverable.

### Steps

```mermaid
graph LR
    A[Summarize Recent Changes] --> B[Update Memories]
    B --> C[Verify Knowledge]
```

1. **Summarize Changes** (`/knowledge:summarize --since 7d`)
   - Aggregates git commits
   - Extracts key decisions
   - Categorizes changes (features, fixes, refactoring)

2. **Update Memories** (`/knowledge:update-memory`)
   - Interactively add insights to Serena memories
   - Document architectural decisions
   - Capture patterns and conventions

3. **Verify Knowledge** (`/knowledge:search`)
   - Confirms new knowledge is discoverable
   - Tests search accuracy
   - Identifies gaps

### Triggers

| Event | Condition | Frequency |
|-------|-----------|-----------|
| Pull request merged | `branch == 'main'` | After each merge |
| Scheduled | N/A | Weekly (Friday 4pm) |

### Outputs
- `weekly-summary.md` - Change summary
- `updated-memories-list.txt` - List of updated memories

### Usage

```bash
# After completing a feature
/knowledge:summarize --since "2025-01-01"
/knowledge:update-memory architecture-decisions

# Verify knowledge
/knowledge:search "API design patterns"
```

### Best Practices
- Update memories immediately after major decisions
- Document WHY, not just WHAT
- Link related concepts
- Review memories quarterly for outdated info

---

## 3. Cost Optimization Workflow

**File**: `.claude/workflows/cost-optimization.yaml`
**Schedule**: Monthly (1st of month)
**Priority**: Medium

### Purpose
Identify cost savings opportunities across cloud services, APIs, and agent operations.

### Steps

```mermaid
graph TD
    A[Generate Cost Report] --> D[Analyze Decision]
    B[Optimize Agent Routing] --> D
    C[Calculate ROI] --> D
    D --> E{Apply Changes?}
```

1. **Cost Report** (`/system:cost-report --period 30d`)
   - Aggregates costs from AWS, GCP, Azure
   - Categorizes by service and environment
   - Identifies top cost drivers
   - Suggests optimization opportunities

2. **Optimize Agent Routing** (`/agent:optimize-routing --optimize-for cost`)
   - Analyzes agent performance vs cost
   - Generates routing rules to reduce costs
   - Projects savings

3. **Calculate ROI** (`/analytics:roi-calculator --list-all`)
   - Evaluates automation ROI
   - Compares time savings vs costs
   - Identifies high-value automations

4. **Decision Analysis** (`/decision:analyze`)
   - Structured analysis of optimization options
   - Weighs tradeoffs (cost vs speed vs quality)
   - Recommends actions

### Decision Points

| Condition | Action | Description |
|-----------|--------|-------------|
| `total_cost > budget` | High-priority alert | Costs exceed budget |
| `projected_savings > $100` | Auto-apply | Apply agent routing optimization |

### Outputs
- `cost-report-${month}.md` - Monthly cost breakdown
- `optimization-plan.md` - Recommended actions
- `roi-summary.json` - Automation ROI data

### Usage

```bash
# Monthly review
/system:cost-report --period 30d --budget 5000
/agent:optimize-routing --optimize-for cost
/analytics:roi-calculator --compare
```

---

## 4. Agent Performance Workflow

**File**: `.claude/workflows/agent-performance.yaml`
**Schedule**: Quarterly (15th of quarter: Jan, Apr, Jul, Oct)
**Priority**: Low

### Purpose
Continuous agent improvement through benchmarking and routing optimization.

### Steps

```mermaid
graph LR
    A[Benchmark Agents] --> B[Optimize Routing]
    B --> C[Dry-Run Validation]
    C --> D{Improvement > 10%?}
    D -->|Yes| E[Request Approval]
```

1. **Benchmark Agents** (`/agent:benchmark --agents all`)
   - Run standardized task suite
   - Measure time, tokens, cost, quality
   - Generate performance matrix

2. **Optimize Routing** (`/agent:optimize-routing --period 90d`)
   - Analyze 90 days of historical data
   - Generate new routing rules
   - Project quality improvement

3. **Dry-Run Validation** (`/agent:optimize-routing --dry-run`)
   - Test new rules on historical tasks
   - Compare old vs new performance
   - Calculate impact

### Decision Points

| Condition | Action | Description |
|-----------|--------|-------------|
| `projected_improvement > 10%` | Request approval | Significant improvement - apply changes? |

### Outputs
- `agent-benchmark-${quarter}.md` - Performance report
- `routing-optimization-${quarter}.yaml` - New routing rules

### Usage

```bash
# Quarterly review
/agent:benchmark --agents all
/agent:optimize-routing --period 90d --optimize-for quality
/agent:optimize-routing --dry-run
```

---

## 5. Integration Health Workflow

**File**: `.claude/workflows/integration-health.yaml`
**Schedule**: Daily (8:00 AM)
**Priority**: High

### Purpose
Keep all external integrations synchronized and healthy (Zoho CRM, Stripe, GitHub).

### Steps

```mermaid
graph TD
    A[Sync Zoho Contacts] --> D[Generate Dashboard]
    B[Analyze Stripe Churn] --> D
    C[Sync GitHub Issues] --> D
```

1. **Sync Zoho Contacts** (`/zoho:sync-contacts zoho-crm gmail`)
   - Bidirectional sync between Zoho CRM and Gmail
   - Detect new, updated, deleted contacts
   - Resolve conflicts

2. **Analyze Stripe Churn** (`/stripe:analyze-churn --create-tasks`)
   - Calculate churn metrics
   - Identify at-risk customers
   - Create CRM follow-up tasks

3. **Sync GitHub Issues** (`/github:sync-issues notion`)
   - Sync open issues to Notion
   - Map labels, assignees, milestones
   - Update existing items

4. **Integration Dashboard** (`/dashboard:generate integrations`)
   - Visual integration health
   - Sync status and metrics
   - Alert on issues

### Decision Points

| Condition | Action | Description |
|-----------|--------|-------------|
| `churn_rate > 5%` | Alert team | Elevated churn - review at-risk customers |
| `conflicts_resolved > 10` | Review required | High conflict count - manual review needed |

### Outputs
- `integration-sync-log-${date}.txt` - Sync activity log
- `churn-analysis-${date}.md` - Churn report
- `integration-dashboard-url` - Live dashboard

### Usage

```bash
# Daily sync
/zoho:sync-contacts zoho-crm gmail --direction two-way
/stripe:analyze-churn --period 3m --create-tasks
/github:sync-issues notion --filter open
```

---

## 6. Enhanced Development Workflow

**File**: `.claude/workflows/dev-workflow-enhanced.yaml`
**Trigger**: Manual
**Priority**: High

### Purpose
End-to-end feature development with automated quality checks and knowledge capture.

### Steps

```mermaid
graph TD
    A[Feature Request] --> B[Scaffold Feature]
    B --> C[Implement Feature]
    C --> D[Run Tests]
    D --> E{Tests Pass?}
    E -->|No| C
    E -->|Yes| F[Security Check]
    F --> G{Secure?}
    G -->|No| C
    G -->|Yes| H[Health Check]
    H --> I{Health > 80?}
    I -->|No| J[Manual Review]
    I -->|Yes| K[Create PR]
    K --> L[Merge to Main]
    L --> M[Summarize Changes]
```

### Detailed Steps

1. **Feature Request** (`/dev:feature-request`)
   - Plan and scope feature
   - Estimate effort
   - Document requirements

2. **Scaffold** (`/dev:scaffold`)
   - Generate boilerplate
   - Follow project patterns
   - Create file structure

3. **Implement** (`/dev:implement`)
   - Full implementation with agent routing
   - Write code following standards
   - Add inline documentation

4. **Test** (`/dev:test`)
   - Run full test suite
   - Check coverage
   - Fix failing tests

5. **Security Check** (`/dev:dependency-check --security-only`)
   - Scan for vulnerabilities
   - Check for exposed secrets

6. **Health Check** (`/system:health-check --category code`)
   - Verify code quality
   - Check linter, types, build
   - Generate health score

7. **Create PR** (`/dev:create-pr`)
   - Auto-generate description
   - Include change summary
   - Link related issues

8. **Merge** (`/dev:merge`)
   - Safety checks before merge
   - Run final tests
   - Update documentation

9. **Summarize** (`/knowledge:summarize --save`)
   - Document what changed and why
   - Update knowledge base
   - Create changelog entry

### Decision Points

| Trigger | Action | Description |
|---------|--------|-------------|
| `test_results == 'failed'` | Halt workflow | Fix tests before proceeding |
| `code_health_score < 80` | Request review | Health below threshold |
| `security_status == 'vulnerabilities_found'` | Halt workflow | Resolve vulnerabilities first |

### Manual Checkpoints

After **health-check**: "Code health: ${code_health_score}/100. Continue?"
After **create-pull-request**: "PR created: ${pr_url}. Ready to merge?"

### Outputs
- `feature-spec.md` - Feature specification
- `pr-${pr_number}.md` - PR details
- `change-summary.md` - Knowledge base update

### Usage

```bash
# Complete workflow
/workflow:execute dev-workflow-enhanced --feature "user authentication"

# Individual steps (manual)
/dev:feature-request "Add OAuth login"
/dev:scaffold "oauth-login" --fullstack
/dev:implement "oauth-login"
/dev:test
/dev:create-pr
/dev:merge
/knowledge:summarize --save
```

---

## Existing Workflows (Import/Adapt)

### Existing: DEVB System

**Location**: `.claude/DEVB_SYSTEM_GUIDE.md`
**Use For**: Solution design with validation before building

**Workflow**: Design → Emulate → Validate → Build

1. `/design:solution` - Create comprehensive design specification
2. `/design:emulate` - Test design without building (dry-run, static analysis, simulation)
3. `/design:validate` - AI validation from 4 perspectives (Security, Performance, Cost, UX)
4. `/design:spec` - Generate complete specifications (diagrams, OpenAPI, test plan)

**When to Use**: Any new feature, workflow chain, infrastructure, or complete solution design

**Import As**: Universal - Already applicable to all projects

---

### Existing: Agent OS Workflow

**Location**: `.claude/commands/agent-os/`
**Use For**: Spec-driven feature development with specialized agents

**Workflow**:

**Phase 1: Planning**
- `/agent-os:plan-product` - Product mission, roadmap, tech stack

**Phase 2: Specification**
- `/agent-os:init-spec` - Initialize spec folder
- `/agent-os:shape-spec` - Gather requirements
- `/agent-os:write-spec` - Create specification
- `/agent-os:verify-spec` - Validate completeness

**Phase 3: Contract & Integration**
- `/agent-os:design-contract` - Unified API contracts
- `/agent-os:design-integration` - Data fetching patterns

**Phase 4: Implementation**
- `/agent-os:create-tasks` - Task breakdown
- `/agent-os:implement-tasks` - Execute with TDD
- `/agent-os:verify-implementation` - Verify completion

**Phase 5: Verification**
- `/agent-os:verify-integration` - End-to-end verification

**When to Use**: Large features requiring detailed specification and multiple agents

**Import As**: Universal - Excellent for complex features

---

### Existing: Standard Dev Workflow

**Location**: `.claude/commands/dev/`
**Use For**: Day-to-day feature development

**Workflow**:
1. `/dev:feature-request` - Plan and scope
2. `/dev:create-branch` - Create feature branch
3. `/dev:implement` - Implement feature
4. `/dev:test` - Run tests
5. `/dev:review` - Self-code review
6. `/dev:create-pr` - Create pull request
7. `/dev:merge` - Merge to main

**When to Use**: Standard feature work without extensive planning

**Import As**: Universal - Core development cycle

**Enhancement**: Use Enhanced Dev Workflow (Workflow #6) which adds:
- `/dev:scaffold` for consistent structure
- `/dev:dependency-check` for security
- `/system:health-check` for quality gates
- `/knowledge:summarize` for documentation

---

### Existing: Productivity Workflow

**Location**: `.claude/commands/`
**Use For**: Universal capture and information retrieval

**Commands**:
- `/capture` - Universal quick capture (auto-routes to Notion/Trello/Drive/KB)
- `/find` - Universal search across Gmail, Calendar, Notion, Trello, Drive, KB
- `/autopilot:predict-tasks` - AI predicts upcoming tasks

**When to Use**: Daily productivity and information management

**Import As**: Universal - Already general-purpose

---

## Workflow Execution

### Manual Execution

Run entire workflow:
```bash
/workflow:execute <workflow-name>
```

Run specific step:
```bash
/<command-name> <arguments>
```

### Automated Execution

Workflows with schedules run automatically:

| Workflow | Frequency | Day/Time |
|----------|-----------|----------|
| Project Health | Weekly | Monday 9:00 AM |
| Knowledge Maintenance | Weekly | Friday 4:00 PM |
| Cost Optimization | Monthly | 1st of month |
| Agent Performance | Quarterly | 15th (Jan, Apr, Jul, Oct) |
| Integration Health | Daily | 8:00 AM |

### Triggering Workflows

Event-based triggers:
- `pull_request_merged` → Knowledge Maintenance
- `branch == 'main'` → Knowledge Maintenance

---

## Workflow Chaining

Combine workflows for complex scenarios:

### Example: New Project Setup
```bash
# 1. Initialize with DEVB
/design:solution "Project X architecture"
/design:emulate <design-id>
/design:validate <design-id>

# 2. Set up health monitoring
/workflow:execute project-health

# 3. Configure integrations
/workflow:execute integration-health

# 4. Start first feature
/workflow:execute dev-workflow-enhanced --feature "user auth"
```

### Example: Monthly Review
```bash
# Cost analysis
/workflow:execute cost-optimization

# Agent performance (quarterly)
/workflow:execute agent-performance

# Knowledge review
/knowledge:summarize --since 30d --format html --save
```

---

## Customization

### Creating Custom Workflows

1. Copy existing workflow YAML as template
2. Modify steps to match your needs
3. Save to `.claude/workflows/custom-workflow.yaml`
4. Test with `/workflow:execute custom-workflow`

### Example Custom Workflow

```yaml
name: custom-onboarding
description: Onboard new team members
trigger: manual

steps:
  - name: generate-docs
    command: /docs:generate --target onboarding

  - name: create-training-plan
    command: /assistant:schedule "New hire training" --duration 2w

  - name: setup-access
    command: /zoho:create-contact "${new_hire_email}"

decision_points:
  - trigger: setup_complete
    action: notify_team
    message: "New hire ${name} onboarded successfully"
```

---

## Best Practices

### Workflow Design
1. **Single Responsibility**: Each workflow has one clear purpose
2. **Composable**: Workflows can be combined and chained
3. **Idempotent**: Safe to run multiple times
4. **Observable**: Clear outputs and progress tracking

### Workflow Execution
1. **Test First**: Run with `--dry-run` before automation
2. **Monitor**: Check outputs and logs regularly
3. **Iterate**: Refine workflows based on actual usage
4. **Document**: Update workflow docs when changing steps

### Workflow Maintenance
1. **Review Quarterly**: Are workflows still relevant?
2. **Optimize**: Remove redundant steps
3. **Update**: Keep commands up-to-date
4. **Archive**: Move unused workflows to archive/

---

## Troubleshooting

### Workflow Fails to Start
- Check command syntax in YAML
- Verify all commands exist
- Check permissions

### Workflow Hangs
- Check for missing dependencies
- Review decision points
- Check manual checkpoint prompts

### Workflow Produces Wrong Output
- Review input parameters
- Check condition logic
- Validate command arguments

---

## Next Steps

1. **Start with Project Health**: `/workflow:execute project-health`
2. **Enable Daily Integration Sync**: `/workflow:execute integration-health`
3. **Try Enhanced Dev Workflow**: On your next feature
4. **Review Monthly Costs**: `/workflow:execute cost-optimization`
5. **Customize**: Create workflows specific to your project

---

**Last Updated**: 2026-01-10
