# Assistant Package Maintenance

Use this checklist to keep the assistant package portable and in sync.

## Workflow

1. Update command/skill/workflow definitions.
2. Normalize command frontmatter.
3. Validate package references.
4. Export adapter artifacts.

## Commands

```bash
npm run fix:command-frontmatter
npm run validate:assistant-package
npm run export:assistant-packages
```

## CI Enforcement

The CI workflow `assistant-package-validate.yml` will fail if:
- `argument-hint` fields are not normalized
- referenced commands are missing
- adapter exports are out of date
