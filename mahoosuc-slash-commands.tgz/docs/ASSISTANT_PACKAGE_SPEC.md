# Assistant Package Spec

Goal: make commands, skills, and workflows portable across coding assistants with a single canonical format.

---

## Canonical Command Syntax

- **Command form**: `/<category>:<name>` (colon is canonical)
- **Aliases**: `/<category>/<name>` MAY be supported by adapters, but should not appear in source docs

---

## Package Layout

- `.claude/commands/<category>/<name>.md` — human-readable command docs
- `.claude/skills/<skill-id>/SKILL.md` — skill definitions
- `.claude/workflows/<workflow-id>.yaml` — workflow definitions

---

## Portable JSON Shapes

### Command

```json
{
  "id": "dev:implement",
  "name": "implement",
  "category": "dev",
  "description": "Implement a new feature with TDD",
  "argumentHint": "--feature <string> [--test <boolean>]",
  "inputSchema": {
    "type": "object",
    "properties": {
      "feature": { "type": "string" },
      "test": { "type": "boolean", "default": true }
    },
    "required": ["feature"]
  },
  "requiredTools": ["Read", "Write", "Bash"],
  "examples": [
    {
      "input": "--feature \"user auth\" --test true",
      "output": "Implemented user auth"
    }
  ],
  "version": "1.0.0",
  "author": "Team",
  "tags": ["development", "tdd"]
}
```

### Skill

```json
{
  "id": "stripe-revenue-analyzer",
  "name": "Stripe Revenue Analyzer",
  "category": "finance",
  "description": "Analyze Stripe revenue trends and churn",
  "capabilities": ["revenue analysis", "churn insights"],
  "requiredTools": ["Read", "Bash"],
  "inputSchema": { "type": "object", "properties": {} },
  "examples": [
    { "input": "--period month", "output": "Report generated" }
  ],
  "version": "1.2.0",
  "author": "Team"
}
```

### Workflow

```json
{
  "id": "dev-workflow-enhanced",
  "name": "Enhanced Development Workflow",
  "description": "Plan → scaffold → implement → test → PR",
  "steps": [
    { "command": "/dev:feature-request", "outputs": ["feature_spec"] },
    { "command": "/dev:scaffold", "dependsOn": ["feature-request-planning"] }
  ],
  "parallelizable": false,
  "estimatedDuration": "10-15 minutes"
}
```

---

## Adapter Guidelines

When porting to a new assistant:

1. Map `requiredTools` to the assistant's tool names.
2. Ensure `/category:name` is accepted (alias slash format if needed).
3. Use JSON Schema for argument validation.
4. Preserve `examples` and `description` for discoverability.

---

## Validation Expectations

- Every command referenced in docs/workflows must exist in `.claude/commands` or `.claude/workflows`.
- All docs must use colon syntax.
- Skills must have `SKILL.md` and be listed in the skills reference.
- Frontmatter `argument-hint` values must be quoted (see `npm run fix:command-frontmatter`).
- Export artifacts must be regenerated after changes (see `npm run export:assistant-packages`).
